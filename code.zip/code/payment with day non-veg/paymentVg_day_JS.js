var unselect;
function selectcolor(){
    document.getElementById("day1").style.backgroundColor=" #F1440D";
    document.getElementById("day1").style.color="white";
    
}
function selectcolor2(){
    document.getElementById("day2").style.backgroundColor=" #F1440D";
    document.getElementById("day2").style.color="white";
}
function selectcolor3(){
    document.getElementById("day3").style.backgroundColor=" #F1440D";
    document.getElementById("day3").style.color="white";
}
function selectcolor4(){
    document.getElementById("day4").style.backgroundColor=" #F1440D";
    document.getElementById("day4").style.color="white";
}
function selectcolor5(){
    document.getElementById("day5").style.backgroundColor=" #F1440D";
    document.getElementById("day5").style.color="white";
   
}
function selectcolor6(){
    document.getElementById("day6").style.backgroundColor=" #F1440D";
    document.getElementById("day6").style.color="white";
    
}
function unselectcolor(){
    document.getElementById("day1").style.backgroundColor=" #FFFFFF";
    document.getElementById("day1").style.color=" #000000";
   
}
function unselectcolor2(){
     document.getElementById("day2").style.backgroundColor=" #FFFFFF";
document.getElementById("day2").style.color=" #000000";

}
function unselectcolor3(){ 
    document.getElementById("day3").style.backgroundColor=" #FFFFFF";
document.getElementById("day3").style.color=" #000000";

}
function unselectcolor4(){ 
    document.getElementById("day4").style.backgroundColor=" #FFFFFF";
document.getElementById("day4").style.color=" #000000";

}
function unselectcolor5(){
    document.getElementById("day5").style.backgroundColor=" #FFFFFF";
    document.getElementById("day5").style.color=" #000000";
   
}
function unselectcolor6(){
    document.getElementById("day6").style.backgroundColor=" #FFFFFF";
    document.getElementById("day6").style.color=" #000000";
   
}
function selectpay(){
    document.getElementById("cardMethod").style.backgroundColor=" #F1440D";
    document.getElementById("cardMethod").style.color="white";
    
}
function unselectpay(){
    document.getElementById("cardMethod").style.backgroundColor=" #FFFFFF";
    document.getElementById("cardMethod").style.color=" #000000";
   
}
function selectpay2(){
    document.getElementById("NetBanking").style.backgroundColor=" #F1440D";
    document.getElementById("NetBanking").style.color="white";
    
}
function unselectpay2(){
    document.getElementById("cardMethod").style.backgroundColor=" #FFFFFF";
    document.getElementById("cardMethod").style.color=" #000000";
   
}
function selectpay3(){
    document.getElementById("COD").style.backgroundColor=" #F1440D";
    document.getElementById("COD").style.color="white";
    
}
function unselectpay3(){
    document.getElementById("COD").style.backgroundColor=" #FFFFFF";
    document.getElementById("COD").style.color=" #000000";
   
}
   
  

