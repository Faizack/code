<?php

$name = filter_var($_POST["fullname"], FILTER_SANITIZE_STRING);
$phone = filter_var($_POST["phone"], FILTER_VALIDATE_INT);
$email = filter_var($_POST["email"], FILTER_VALIDATE_EMAIL);
$password = $_POST["password"];
$address = filter_var($_POST["address"], FILTER_SANITIZE_STRING);

$conn = new mysqli ('localhost','root','','data');

if($conn->connect_error){
    die("Connection failed : ".$conn->connect_error);
}
else {
    $stl = $conn->prepare("INSERT INTO userdata (fullname, phoneno, email, password, address) VALUES (?,?,?,?,?)");
    $stl->bind_param("sisss",$name,$phone,$email,$password,$address);
    $stl->execute();
    header ("Location: login.html");
    $stl->close();
    $conn->close();
}




?>