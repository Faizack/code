function selectpay(){
    document.getElementById("b1").style.backgroundColor=" #F1440D";
    document.getElementById("b1").style.color="white";
    
}
function unselectpay(){
    document.getElementById("b1").style.backgroundColor=" #FFFFFF";
    document.getElementById("b1").style.color=" #000000";
   
}
function selectpay2(){
    document.getElementById("b2").style.backgroundColor=" #F1440D";
    document.getElementById("b2").style.color="white";
    
}
function unselectpay2(){
    document.getElementById("b2").style.backgroundColor=" #FFFFFF";
    document.getElementById("b2").style.color=" #000000";
   
}
function selectpay3(){
    document.getElementById("b3").style.backgroundColor=" #F1440D";
    document.getElementById("b3").style.color="white";
    
}
function unselectpay3(){
    document.getElementById("b3").style.backgroundColor=" #FFFFFF";
    document.getElementById("b3").style.color=" #000000";
   
}