<?php

$email = $_POST["email"];
$password = $_POST["password"];

$conn = new mysqli ('localhost', 'root','','data');

if($conn->connect_error){
    die("Connection failed : ".$conn->connect_error);
}
else {
    $stl = $conn->prepare("select * from userdata where email=? and password=?");
    $stl->bind_param("ss",$email,$password);
    $stl->execute();
    $result = $stl->get_result();
    while ($row = $result->fetch_assoc()){
        if($row==true)
    {
        header ("Location: home.html");
    }
    }
    echo "<h1>Wrong Email and Password</h1>";
}



?>